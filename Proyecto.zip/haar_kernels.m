function [kernels] = haar_kernels(frecs, sizes, angles)
%HAAR_KERNEL Summary of this function goes here
%   Detailed explanation goes here
  if length(frecs) ~= length(sizes) || length(sizes) ~= length(angles)
   error('myfuns:haar:InputUnmatch', ...
        'Length of frecs, sizes and angles must agree.');
  end

  index = 0;
  kernels = cell(length(frecs),1);
  for ii =1:length(frecs)
    f = frecs{ii};
    s = sizes{ii};
    a = angles{ii};
    for angle = 0:(a-1)
      ang = (pi*angle)/a;
      index = index + 1;
      if length(f) == 2
        kernels{ii} = haar_checker(f(1), f(2), s(1), s(2), ang, 0,0);
      elseif length(f) == 4
        kernels{ii} = haar_wave(f(1), f(2), f(3), f(4), s(1), s(2), ang, 0,0);
      else
        error('myfuns:haar:InvalidInput', ...
          'Length of frecs{ii} must be 2 or 4.');
      end
    end
  end

end

