frecs = {[1, 1], [5, 3], [7, 7, 2, 2]};
sizes = {[10, 20], [10, 10], [20, 20]};
angles = {8, 8, 3};

img = imread('./faces_lfwa_3/face_0005_0015.png');

imagesc(img);

imgs = {img};

result = haar(imgs, frecs, sizes, angles);

imagesc(result{1});



