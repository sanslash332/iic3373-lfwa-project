
%% Extracci�n de Caracter�sticas

% b(1).name = 'basicint';
% b(1).options.show = 0;
% b(1).options.type   = 2;    % intensity

frecs = {[1, 1], [5, 3], [7, 7, 2, 2]};
sizes = {[10, 20], [10, 10], [20, 20]};
angles = {8, 8, 3};


b(1).name = 'lbp';
b(1).options.type = 2;
b(1).options.vdiv = 1;                  % one vertical divition
b(1).options.hdiv = 1;                  % one horizontal divition
b(1).options.semantic = 0;              % classic LBP
b(1).options.samples  = 8;              % number of neighbor samples
b(1).options.mappingtype = 'ri';

b(2).name = 'haralick';
b(2).options.type = 2;
b(2).options.dharalick = 2;
b(2).options.show = 0;

b(3).name = 'gabor';
b(3).options.type = 2;
b(3).options.Lgabor  = 8;                 % number of rotations
b(3).options.Sgabor  = 8;                 % number of dilations (scale)
b(3).options.fhgabor = 2;                 % highest frequency of interest
b(3).options.flgabor = 0.1;               % lowest frequency of interest
b(3).options.Mgabor  = 21;                % mask size
b(3).options.show    = 0;

b(4).name = 'haar';
b(4).options.type = 2;
b(4).options.kernels = haar_kernels(frecs, sizes, angles);
b(4).options.div_x = 4;
b(4).options.div_y = 4;
b(4).options.show   = 0;

f.path          = './faces_lfwa_3/';  % directory of the images
f.prefix        =  '*';
f.extension     =  '.png';
f.gray          = 1;
f.imgmin        = 1;
f.imgmax        = 5000;

f

opf.b = b;
opf.channels = 'g';              % grayscale image


[caracteristicas,labels_c,S] = Bfx_files(f,opf);
persona =ones(length(S),1);

for k=1:length(S)
    name = S(k,:);
    persona(k) = str2double(name(9:12));
end

save('paso1.m','caracteristicas','persona','labels_c');
%%
